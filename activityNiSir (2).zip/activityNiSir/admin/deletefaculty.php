<?php
include ("databse/dbcon.php");


if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM faculty WHERE id = $id";
    if ($con->query($sql)) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Deleted</h3>";
    } else {
        $_SESSION['error'] = "Error deleting the record: " . $con->error;
    }

    $con->close();  
} else {
    $_SESSION['error'] = "Invalid record ID";
}

header("location: facultyTable.php");  
?>