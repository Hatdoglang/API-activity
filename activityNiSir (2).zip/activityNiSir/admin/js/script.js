 const form = document.querySelector("form"),
    nextBtn = form.querySelector(".nextBtn"),
    backBtn = form.querySelector(".backBtn"),
    allInput = form.querySelectorAll(".first input, .first select"); // Include select dropdown in the list

    nextBtn.addEventListener("click", () => {
    allInput.forEach(input => {
        console.log(input.first, input.value); // Log the field name and value
        if (input.value != "") {
            form.classList.add('secActive');
        } else {
            form.classList.remove('secActive');
        }
    })
})

backBtn.addEventListener("click", () => form.classList.remove('secActive'));