<?php
include("index.php");
include("databse/dbcon.php");


$student_query = "SELECT * FROM student";
$student_result = mysqli_query($con, $student_query);

if (isset($_SESSION['success'])) {
    echo '<div class="success-message">' . $_SESSION['success'] . '</div>';
    unset($_SESSION['success']); 
}

if (isset($_SESSION['error'])) {
    echo '<div class="error-message">' . $_SESSION['error'] . '</div>';
    unset($_SESSION['error']); 
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Students</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>
    <!-- Navigation and other HTML elements... -->

    <div class="main">
        <style>
            .list a {
                color: #fff;
                background: #5500cb;
                height: 45px;
                width: 190px;
                font-size: 18px;
                border-radius: 5px;
                cursor: pointer;
            }

            .recent-Articles {
                margin-left: 60vh;
                margin-top: 100px;
            }

            .data-table {
                width: 100%;
                max-width: 100%;
                border-collapse: collapse;
                white-space: nowrap;
                margin-top: 20px;
                background-color: #fff;
                border-radius: 20px;
                box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
            }

            .data-table td.no-wrap {
                white-space: nowrap;
                background-color: #ffffff;
                text-align: center;
            }

            .search-container {
                text-align: center;
                margin: 20px 0;
            }

            #search-form {
                display: inline-block;
            }

            #search-input {
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 5px;
                margin-right: 5px;
            }

            button[type="submit"] {
                background-color: #5500cb;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 5px;
                cursor: pointer;
            }
        </style>

        <div style="margin-left:35vh; margin-top:-17vh;" class="report-container">
            <div class="report-header">
                <h1 class="recent-Articles">List of Student</h1>
            </div>

            <div class="report-body">
                <div class="list">
                    <button><a href="student.php">ADD NEW STUDENT</a></button>
                </div>
                <div class="search-container">
                    <form id="search-form">
                        <input type="text" id="search-input" placeholder="Search for students">
                        <button type="submit">Search</button>
                    </form>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Course</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Display data from the "student" table
                        while ($row = mysqli_fetch_assoc($student_result)) {
                            echo '<tr>';
                            echo '<td class="no-wrap">' . $row['idnumber'] . '</td>';
                            echo '<td class="no-wrap">' . $row['lname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['fname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['mname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['course'] . '</td>';
                            echo '<td class="action-buttons">';
                            echo '<a class="edit-button" href="editstudent.php?edit=' . $row['id'] . '">EDIT</a>';
                            echo '<a style="cursor:pointer;" class="delete-button" onclick="confirmDelete(' . $row['id'] . ')">DELETE</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Function to show confirmation dialog before deleting
        function confirmDelete(studentId) {
            var result = confirm("Are you sure you want to delete this student?");
            if (result) {
                window.location.href = 'delete.php?id=' + studentId;
            }
        }
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchForm = document.getElementById("search-form");
        const searchInput = document.getElementById("search-input");
        const dataTable = document.querySelector(".data-table");

        searchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const searchValue = searchInput.value.toLowerCase();
            const rows = dataTable.querySelectorAll("tbody tr");

            rows.forEach((row) => {
                const rowData = row.textContent.toLowerCase();
                if (rowData.includes(searchValue)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    });
    </script>
</body>

</html>
