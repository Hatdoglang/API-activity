<?php
include("index.php");
include ("databse/dbcon.php");
$faculty_query = "SELECT * FROM faculty";
$faculty_result = mysqli_query($con, $faculty_query);

// Query to get data from the "student" table
$student_query = "SELECT * FROM student";
$student_result = mysqli_query($con, $student_query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>GRading System</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>
    <style>
    .list a {
        color: #fff;
        background: #5500cb;
        height: 45px;
        width: 160px;
        font-size: 18px;
        border-radius: 5px;
        cursor: pointer;
    }

    .recent-Articles {
        margin-left: 50vh;
        margin-top: 100px;
    }

    .data-table {
        width: 100%;
        max-width: 100%;
        /* Adjusted to ensure responsiveness */
        border-collapse: collapse;
        white-space: nowrap;
        margin-top: 20px;
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
    }

    .data-table td.no-wrap {
        white-space: nowrap;
        background-color: #ffffff;
        text-align: center;
    }

    .search-container {
        text-align: center;
        margin: 20px 0;
    }

    #search-form {
        display: inline-block;
    }

    #search-input {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 5px;
    }

    button[type="submit"] {
        background-color: #5500cb;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 5px;
        cursor: pointer;
    }
    
    </style>
    </nav>
    </div>
    <div class="main">
        <div class="box-container">
            <div class="box box2">
                <div class="text">
                    <h2 class="topic">Total Faculty</h2>
                </div>

                <?php
                        $dash_category_query = "SELECT * from faculty";
                        $dash_category_query_run = mysqli_query($con, $dash_category_query);

                        if ($category_total = mysqli_num_rows($dash_category_query_run)) {
                            echo '<h2 class="topic-heading" style="color:white;">' . $category_total . '</h2>';
                        } else { 
                            echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">no data</h2>';
                        }
                        ?>
            </div>

            <div style='background: radial-gradient(circle, rgba(252,70,107,1) 0%, rgba(63,94,251,1) 100%);'
                class="box box3">
                <div class="text">
                    <h2 class="topic">Total Students</h2>
                </div>

                <?php
                        $dash_category_query = "SELECT * from student";
                        $dash_category_query_run = mysqli_query($con, $dash_category_query);

                        if ($category_total = mysqli_num_rows($dash_category_query_run)) {
                            echo '<h2 class="topic-heading" style="color:white;">' . $category_total . '</h2>';
                        } else {
                            echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">no data</h2>';
                        }
                        ?>
            </div>

            <div class="box box4">
                <div class="text">
                    <h2 class="topic">No. of Students <br> every<br> institute/course</h2>
                </div>
                <?php
                            $dash_category_query = "SELECT * from student";
                            $dash_category_query_run = mysqli_query($con, $dash_category_query);

                            if ($category_total = mysqli_num_rows($dash_category_query_run)) {
                                echo '<h2 class="topic-heading" style="color:white;">' . $category_total . '</h2>';
                            } else {
                                echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">no data</h2>';
                            }
                        ?>

            </div>
        </div>

        <div style="margin-left:25vh;" class="report-container">
            <div class="report-header">
                <h1 class="recent-Articles">Registered Students</h1>
            </div>

            <div class="search-container">
                <form id="search-form">
                    <input type="text" id="search-input" placeholder="Search for students">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div class="report-body">
                <table class="data-table">


                    <thead>
                        <tr>
                            <th>Id Number</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Gender</th>
                            <th>Course</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                // Display data from the "student" table
                while ($row = mysqli_fetch_assoc($student_result)) {
                    echo '<tr>';
                    echo '<td class="no-wrap">' . $row['idnumber'] . '</td>';
                    echo '<td class="no-wrap">' . $row['lname'] . '</td>';
                    echo '<td class="no-wrap">' . $row['fname'] . '</td>';
                    echo '<td class="no-wrap">' . $row['mname'] . '</td>';
                    echo '<td class="no-wrap">' . $row['gender'] . '</td>';
                    echo '<td class="no-wrap">' . $row['course'] . '</td>';
               
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const searchForm = document.getElementById("search-form");
            const searchInput = document.getElementById("search-input");
            const dataTable = document.querySelector(".data-table");

            searchForm.addEventListener("submit", function(e) {
                e.preventDefault();
                const searchValue = searchInput.value.toLowerCase();
                const rows = dataTable.querySelectorAll("tbody tr");

                rows.forEach((row) => {
                    const rowData = row.textContent.toLowerCase();
                    if (rowData.includes(searchValue)) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            });
        });
        </script>

</body>

</html>