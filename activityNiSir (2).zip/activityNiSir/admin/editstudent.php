 <?php

session_start(); // Start the session
include ("databse/dbcon.php");

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    // Check if the ID exists in the database
    $sql = "SELECT * FROM student WHERE id = '$id'";
    $result = $con->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            // Handle the case where the ID does not exist in the database
            echo "Record not found.";
            exit();
        }
    } else {
        // Handle the case where the database query has an error
        echo "Database error: " . $con->error;
        exit();
    }
} else {
    // Handle the case where 'edit' parameter is not set in the URL
    echo "Invalid request.";
    exit();
}
?>

 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Student Edit Form</title>
     <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 </head>

 <body>
     <style>
     * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Poppins', sans-serif;
     }

     body {
         width: 100%;
         background: #dfe9f5;
         display: flex;
         justify-content: center;
         align-items: center;
     }

     .registration-container {
         background: transparent;
         margin-top: 3%;
         padding: 3%;
         display: flex;
         justify-content: center;
         align-items: center;
         margin-top: 10px;
     }

     .details-section {

         background: #fff;
         border-radius: 15px;
         height: 770px;
         box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.1);
     }

     h2 {
         text-align: center;
         color: #495057;
     }

     .three-details-item {
         display: flex;
         justify-content: space-between;
         flex-wrap: wrap;
     }

     label {
         width: calc(33.33% - 20px);
         margin-bottom: 20px;
     }

     label p {
         font-weight: 650;
         margin-bottom: 5px;
     }

     input {
         width: 90%;
         margin-left: 10px;
         height: 40px;
         border-radius: 5px;
         padding: 0 15px;


     }

     select {
         width: 90%;
         margin-left: 10px;
         height: 40px;
         border-radius: 5px;
         padding: 0 15px;


     }


     .container button,
     .backBtn {
         display: flex;
         align-items: center;
         justify-content: center;
         height: 45px;
         max-width: 200px;
         width: 100%;
         border: none;
         outline: none;
         color: #fff;
         border-radius: 5px;
         margin: 25px 0;
         background-color: #4070f4;
         transition: all 0.3s linear;
         cursor: pointer;
     }

     .container button,
     .bacckBtn {
         display: flex;
         align-items: center;
         justify-content: center;
         height: 45px;
         max-width: 200px;
         width: 100%;
         border: none;
         outline: none;
         color: #fff;
         border-radius: 5px;
         margin: 25px 0;
         background-color: #4070f4;
         transition: all 0.3s linear;
         cursor: pointer;
     }

     .container button,
     .container .backBtn {
         font-size: 16px;
         font-weight: 400;
     }

     .container button,
     .container .bacckBtn {
         font-size: 16px;
         font-weight: 400;
     }

     button:hover {
         background-color: #265df2;
     }





     .buttons {
         position: absolute;
         margin-top: 200px;
         width: 900px;
         display: flex;
         align-items: center;
     }

     .buttons button,
     .backBtn {
         margin-right: 14px;
     }

     form {
         margin: 0 90px;
     }

     form h4 {
         font-size: 20px;
         font-weight: 600;
     }

     .buttons button,
     .bacckBtn {
         margin-right: 14px;
     }
     </style>
     <section class="registration-container">
         <section class="details-section">
             <form action="updatestudent.php" method="post" class="registration-form" id="registration-form">
                 <!-- Student Details Section -->
                 <h2>Edit Details</h2>

                 <h4>Student Details</h4>
                 <section class="personal-details">
                     <div class="three-details-item">
                         <label>
                             <p>ID</p>
                             <input type="text" name="id" value="<?= $row['id']; ?>" readonly>
                         </label>
                         <label>
                             <p>Student ID</p>
                             <input type="text" name="idnumber" value="<?= $row['idnumber']; ?>"
                                 placeholder="Student ID" required>
                         </label>
                         <label>
                             <p>First Name</p>
                             <input type="text" name="fname" value="<?= $row['fname']; ?>" placeholder="First Name"
                                 required>
                         </label>
                         <label>
                             <p>Last Name</p>
                             <input type="text" name="lname" value="<?= $row['lname']; ?>" placeholder="Last Name"
                                 required>
                         </label>
                         <label>
                             <p>Middle Name</p>
                             <input type="text" name="mname" value="<?= $row['mname']; ?>" placeholder="Middle"
                                 required>
                         </label>
                         <label>
                             <p>Gender</p>
                             <select name="gender" required>
                                 <option value="Male" <?php if ($row['gender'] == 'Male') echo 'selected'; ?>>Male
                                 </option>
                                 <option value="Female" <?php if ($row['gender'] == 'Female') echo 'selected'; ?>>Female
                                 </option>
                                 <option value="Other" <?php if ($row['gender'] == 'Other') echo 'selected'; ?>>Other
                                 </option>
                             </select>
                         </label>

                     </div>

                     <div class="three-details-item">
                         <label>
                             <p>Institute</p>
                             <select name="institute" required>
                                 <option value="FCDSET" <?= ($row['institute'] == 'FCDSET') ? 'selected' : ''; ?>>FCDSET
                                 </option>
                                 <option value="FGBM" <?= ($row['institute'] == 'FGBM') ? 'selected' : ''; ?>>FGBM
                                 </option>
                                 <option value="FALS" <?= ($row['institute'] == 'FALS') ? 'selected' : ''; ?>>FALS
                                 </option>
                                 <option value="FNAHS" <?= ($row['institute'] == 'FNAHS') ? 'selected' : ''; ?>>FNAHS
                                 </option>
                                 <option value="UG FTED" <?= ($row['institute'] == 'UG FTED') ? 'selected' : ''; ?>>UG
                                     FTED</option>
                             </select>
                         </label>

                         <label>
                             <p>Course</p>
                             <input type="text" name="course" value="<?= $row['course']; ?>" placeholder="Course"
                                 required>
                         </label>
                         <label>
                             <p>Date of Birth</p>
                             <input type="date" name="dob" value="<?= $row['dob']; ?>" placeholder="Date of Birth"
                                 required>
                         </label>

                     </div>
                     <h4>Home Address</h4>
                     <div class="three-details-item">
                         <label>
                             <p>Province</p>
                             <input type="text" name="province" value="<?= $row['province']; ?>" placeholder="Province"
                                 required>
                         </label>

                         <label>
                             <p>Municipality</p>
                             <input type="text" name="municipality" value="<?= $row['municipality']; ?>"
                                 placeholder="Municipality" required>
                         </label>
                         <label>
                             <p>Barangay</p>
                             <input type="text" name="barangay" value="<?= $row['barangay']; ?>" placeholder="Barangay"
                                 required>
                         </label>
                         <label>
                             <p>Purok</p>
                             <input type="text" name="purok" value="<?= $row['purok']; ?>" placeholder="Purok" required>
                         </label>

                         <label>
                             <p>Zip Code</p>
                             <input type="text" name="zipcode" value="<?= $row['zipcode']; ?>" placeholder="Zip Code"
                                 required>
                         </label>
                         <label>
                             <p>Contact No.</p>
                             <input type="text" name="student_contact" value="<?= $row['student_contact']; ?>"
                                 placeholder="Contact" required>
                         </label>
                     </div>

                     <h4>In-case of Emergency</h4>
                     <div class="three-details-item">
                         <label>
                             <p>Guardian</p>
                             <input type="text" name="guardian" value="<?= $row['guardian']; ?>" placeholder="Guardian"
                                 required>
                         </label>
                         <label>
                             <p>Contact Number</p>
                             <input type="text" name="contnumber" value="<?= $row['contnumber']; ?>"
                                 placeholder="Contact Number" required>
                         </label>
                         <label>
                             <p>Address</p>
                             <input type="text" name="address" value="<?= $row['address']; ?>" placeholder="Address"
                                 required>
                         </label>
                     </div>
                     <div class="bacckBtn" onclick="cancelRegistration()">
                         <i class="uil uil-navigator"></i>

                         <span class="btntext">Cancel</span>
                     </div>
                     <button style="margin-left:30vh; margin-top:-70px;" class="bacckBtn" type="submit" name="update">
                         <span class="bacckBtn">update</span>
                         <i class="uil uil-navigator"></i>
                     </button>
                 </section>
             </form>
         </section>
     </section>

     </section>
 </body>
 <script>
function cancelRegistration() {
    console.log("Cancel Registration function called");
    window.location.href = 'studenttable.php';
}
 </script>

 </html>