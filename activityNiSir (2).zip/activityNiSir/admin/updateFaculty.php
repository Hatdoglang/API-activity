<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $fname = $_POST['f_name'];
    $lname = $_POST['l_name'];
    $mname = $_POST['m_name'];
    $dob = $_POST['DOB'];
    $gender = $_POST['Gender'];
    $institute = $_POST['institute'];
    $course = $_POST['Course'];
    $contactNum = $_POST['ContactNum'];
    

    // Update the record in the database
    $updateSql = "UPDATE faculty SET f_name=?, l_name=?, m_name=?, DOB=?, Gender=?, institute=?, Course=?, ContactNum=? WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param("ssssssssi", $fname, $lname, $mname, $dob, $gender, $institute, $course, $contactNum, $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Updated</h3>";
        $stmt->close();
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    // Redirect to the dashboard page
    header("location: facultyTable.php");
}
?>