<?php
$con = mysqli_connect("localhost", "root", "", "dbapi") or die(mysql_error());
?>