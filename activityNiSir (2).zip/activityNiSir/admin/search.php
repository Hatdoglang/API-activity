<?php
include ("databse/dbcon.php");


$return = '';
if (isset($_POST['query'])) {
    $search = mysqli_real_escape_string($con, $_POST['query']);
    $query = "SELECT * FROM student
        WHERE ID LIKE '%" . $search . "%'
        OR lname LIKE '%" . $search . "%'
        OR mname LIKE '%" . $search . "%'
        OR fname LIKE '%" . $search . "%'
        OR course LIKE '%" . $search . "%'
        ";
} else {
    $query = "SELECT * FROM student";
}

$result = mysqli_query($con, $query);

if (mysqli_num_rows($result) > 0) {
    $return .= '
    <table border="1" width="100%" id="table">
    <tr style="background:black;color:#fff">
        <th align="center">Last Name</th>
        <th align="center">First Name</th>
        <th align="center">Middle Name</th>
        <th align="center">Gender</th>
        <th align="center">Course</th>
        <th align="center">Actions</th>
    </tr> <tbody>';

    while ($row = mysqli_fetch_array($result)) {
        $return .= '
            <tr>
                <td align="center">' . $row['lname'] . '</td>
                <td align="center">' . $row['fname'] . '</td>
                <td align="center">' . $row['mname'] . '</td>
                <td align="center">' . $row['gender'] . '</td>
                <td align="center">' . $row['course'] . '</td>
                <td align="center">
                    <button class="edit-button"><a href="edit.php?edit=' . $row['ID'] . '">EDIT</a></button>
                    <button class="delete-button"><a href="delete.php?delete=' . $row['ID'] . '">DELETE</a></button>
                </td>
            </tr>
        ';
    }
    echo $return;
} else {
    echo '<span style="color:#fff;background:red;padding:5px;width:100%;">No results containing all your search terms were found!</span>';
}
?>
