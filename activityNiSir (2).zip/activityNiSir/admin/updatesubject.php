<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $code = $_POST['code'];
    $type = $_POST['type'];
    $unit = $_POST['unit'];
    $desc = $_POST['description'];
    $course = $_POST['ncourse'];
    $institute = $_POST['ninstitute'];
   
    

    // Update the record in the database
    $updateSql = "UPDATE subjects SET code=?, type=?, unit=?, description=?, ncourse=?, ninstitute=? WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param("ssssssi", $code, $type, $unit, $desc, $course, $institute, $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Deleted</h3>";
        
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    // Redirect to the dashboard page
    header("location: subjectTable.php");
}
?>