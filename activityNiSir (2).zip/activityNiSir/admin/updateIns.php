<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $idnumber = $_POST['idnumber'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mname = $_POST['mname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $studentNo = $_POST['student_contact'];
    $province = $_POST['province'];
    $municipality = $_POST['municipality'];
    $barangay = $_POST['barangay'];
    $purok = $_POST['purok'];
    $zipcode = $_POST['zipcode'];
    $guardian = $_POST['guardian'];
    $contnumber = $_POST['contnumber'];
    $address = $_POST['address'];

    // Update the record in the database
    $updateSql = "UPDATE student SET 
        idnumber=?, fname=?, lname=?, mname=?, dob=?, gender=?, institute=?, course=?, student_contact=?,
        province=?, municipality=?, barangay=?, purok=?, zipcode=?,
        guardian=?, contnumber=?, address=?
        WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param(
        "sssssssssssssssssi", // Order of placeholders matches the order of data types
        $idnumber, $fname, $lname, $mname, $dob, $gender, $institute, $course, $studentNo,
        $province, $municipality, $barangay, $purok, $zipcode,
        $guardian, $contnumber, $address, $id
    );

    if ($stmt->execute()) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Updated</h3>";
        $stmt->close();
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    header("location: instituteTable.php");
    exit();
}
?>