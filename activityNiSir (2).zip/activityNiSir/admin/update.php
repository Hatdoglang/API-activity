<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mname = $_POST['mname'];
    $gender = $_POST['gender'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $dob = $_POST['dob'];
    $province = $_POST['province'];
    $municipality = $_POST['municipality'];
    $barangay = $_POST['barangay'];
    $purok = $_POST['purok'];
    $zipcode = $_POST['zipcode'];
    $guardian = $_POST['guardian'];
    $contnumber = $_POST['contnumber'];
    $address = $_POST['address'];

    // Update the record in the database
    $updateSql = "UPDATE student SET 
        fname=?, lname=?, mname=?, gender=?, institute=?, course=?,
        dob=?, province=?, municipality=?, barangay=?, purok=?, zipcode=?,
        guardian=?, contnumber=?, address=?
        WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param(
        "sssssssssssssssi",
        $fname, $lname, $mname, $gender, $institute, $course,
        $dob, $province, $municipality, $barangay, $purok, $zipcode,
        $guardian, $contnumber, $address, $id
    );

    if ($stmt->execute()) {
        $_SESSION['success'] = "Record successfully updated";
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    // Redirect to the dashboard page
    header("location: dashboard.php");
}
?>